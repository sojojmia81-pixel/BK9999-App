BK9999 WebView Android App
===========================

এই project খুললে Android app তৈরি করা যাবে, যেটি:
http://bk9999.bond
ওয়েবসাইটটি WebView-এর ভিতরে চালাবে।

যেভাবে APK বানাবেন:
1. Android Studio ইনস্টল করুন।
2. এই ZIP Extract করুন।
3. Android Studio > Open দিয়ে extracted "bk9999_webview_app" folder খুলুন।
4. Gradle sync শেষ হতে দিন।
5. Build > Build APK(s) নির্বাচন করুন।
6. APK তৈরি হলে app/build/outputs/apk/debug/app-debug.apk ফাইলে পাবেন।

নোট:
- আপনার বর্তমান URL HTTP হওয়ায় usesCleartextTraffic=true রাখা হয়েছে।
- HTTPS চালু করলে পরে এটিকে false করা নিরাপদ।
- ওয়েবসাইটের login/data server-side থাকলে অ্যাপ থেকে একই website data ব্যবহার করবে।
